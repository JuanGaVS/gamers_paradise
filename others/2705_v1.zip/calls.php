<?php
	switch( $_POST[ 'method' ] ){
        case 'changeQuestions':
            //addRegister( $_POST[ 'name' ], $_POST[ 'pin' ], $_POST[ 'phone' ], $_POST[ 'email' ] );
        break;
	}//Fin de switch.
?>