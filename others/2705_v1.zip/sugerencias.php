<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>GamerParadise</title>
	<link href="css/sugerencias.css" rel="stylesheet" type="text/css" media="screen">
</head>

<body>
<div id="wrapper">
	<div id="titulacion">
		<div id="text" >
			<h1> SUGERENCIAS PARA VOS</h1>
			<h2> HAZ CLICK PARA VER UN REVIEW DEL JUEGO</h2>
		</div>
</div>
	
<div id="mas-populares" >
    <h1>MAS POPULARES</h1>
    </div>
    
    <div id="sugerencias">
    
		<div class="columna" >
			<div class= "filas"></div>
            
			<input class="seleccion" type="radio"; id="radio1" name="seleccion" value="1"/>
			<div class= "filas"></div>
			<input class="seleccion" type="radio"; id="radio2" name="seleccion" value="2"/>
			<div class= "filas"></div>
			<input class="seleccion" type="radio"; id="radio3" name="seleccion" value="3"/>
		</div>
		<div class= "columna">
		<div class= "filas"></div>
			<input class="seleccion" type="radio"; id="radio4" name="seleccion" value="4"/>
			<div class= "filas"></div>
			<input class="seleccion" type="radio"; id="radio5" name="seleccion" value="5"/>
	  </div>
	</div>
	<div id="escoger"> </escoger>
</div>

<script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>

<?php

?>

</body>
</html>
