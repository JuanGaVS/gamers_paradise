<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ChoiceGame
 *
 * @author Kevin
 */
class ChoiceGame {
    //put your code here
    
    private $choice;
    private $game;
    
    public function getChoice() {
        return $this->choice;
    }

    public function setChoice($choice) {
        $this->choice = $choice;
    }

    public function getGame() {
        return $this->game;
    }

    public function setGame($game) {
        $this->game = $game;
    }



    
}

?>
