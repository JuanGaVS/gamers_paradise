<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>GamerParadice</title>
	<link href="css/sugerencias.css" rel="stylesheet" type="text/css" media="screen">
</head>

<body>
<div id="wrapper">
	<div id="titulacion">
		<div id="text" >
			<h1> SUGERENCIAS PARA VOS</h1>
			<h2> HAZ CLICK PARA VER UN REVIEW DEL JUEGO</h2>
		</div>
		
		
	</div>
	<div id="sugerecias">
		<div class= "Columna">
			<div class= "filas"></div>
			<div class= "filas seleccion"></div>
			<div class= "filas"></div>
			<div class= "filas seleccion"></div>
			<div class= "filas"></div>
			<div class= "filas seleccion"></div>
		</div>
		<div class= "Columna"></div>
		<div class= "filas"></div>
			<div class= "filas seleccion"></div>
			<div class= "filas"></div>
			<div class= "filas seleccion"></div>
			<div class= "filas"></div>
			<div class= "filas seleccion"></div>
		<div class= "Columna"></div>
		<div class= "filas"></div>
			<div class= "filas seleccion"></div>
			<div class= "filas"></div>
			<div class= "filas seleccion"></div>
			<div class= "filas"></div>
			<div class= "filas seleccion"></div>
	</div>
	<div id="escoger"> </escoger>
</div>

<script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>

<?php

?>

</body>
</html>
