<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Instrucciones</title>
<link href="css/estilos.css" rel="stylesheet" type="text/css" media="screen">
</head>

<body>

<div id="wrapper">

	<div id="titulo">
    	<h1 class="titles">INSTRUCCIONES DE LA PROMOCIÓN</h1>
    </div>
    
	
  	<div id="instrucciones">
    	<p class="paragraphs-12">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id magna a velit blandit aliquet vel ut nisl. Pellentesque vel odio nibh. Ut egestas, eros et pulvinar elementum, tellus sem tincidunt arcu, a hendrerit sapien ante eget lorem. Mauris ullamcorper justo bibendum lectus posuere hendrerit. Nullam et nibh sit amet nulla pharetra luctus. Sed vel magna et elit gravida vehicula vel sit amet mauris. In nec tortor et tellus vestibulum semper nec faucibus arcu. Duis tellus lectus, tempus et accumsan in, porta eget purus. Pellentesque rutrum eros consectetur tellus venenatis ac porta odio consectetur. Nulla egestas pretium quam et rhoncus.</p>
    	<br/>

<p class="paragraphs-12">Nunc placerat suscipit tincidunt. Quisque pretium, enim nec pellentesque hendrerit, purus ligula egestas nibh, auctor bibendum arcu purus vitae neque. Proin interdum placerat tortor sit amet tincidunt. Duis suscipit ipsum id diam gravida mollis. Cras sollicitudin commodo eleifend. Pellentesque condimentum bibendum commodo. Maecenas ipsum nisl, placerat in commodo eget, placerat in nibh. </p>
  </div>
  
  <div id="console-tv"></div>
  <div id="couch-friends"></div>
    
    <div id="footer">
                <h2 id="footer-title"><a href="#">PRIVACIDAD</a> | <a href="#">REGLAS</a></h2>
                <p class="information">Lorem ipsum dolor sit anet blablalba</p>
    </div>
  </div>
</div>
</body>
</html>
