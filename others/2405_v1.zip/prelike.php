<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Prelike</title>
<link href="css/estilos.css" rel="stylesheet" type="text/css" media="screen">
</head>

<body>
	
    <div id="prelike">
    	
        <div id="click-like"></div>
        <div id="listo-jugar">
        	<h1 class="titles">¿LISTO PARA JUGAR?</h1>
            <div id="hr"></div>
            <p class="paragraphs">Participa llenando las preguntas de nuestra encuesta. Tú y tus amigos podrían ser quienes estén en el sofá la próxima vez. No dejes pasar esta oportunidad.</p>
        </div>
        <div id="footer">
                <h2 id="footer-title"><a href="#">PRIVACIDAD</a> | <a href="#">REGLAS</a></h2>
                <p class="information">Lorem ipsum dolor sit anet blablalba</p>
        </div>
        
    </div>

</body>
</html>
