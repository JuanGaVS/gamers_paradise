gamers_paradise
===============

Proyecto Multimedios

Juan Gabriel Villalobos Solera  A96802
Kevin Jesus Porras Zumbado B04898
Pablo Roberto Gonzalez Herrera B02735
Juan Carlos Jimenez Chavarria A83232
Juan Miguel Arguedas Mejias A90551
